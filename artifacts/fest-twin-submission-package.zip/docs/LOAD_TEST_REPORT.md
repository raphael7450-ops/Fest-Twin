# Fest-Twin 부하 테스트 결과 보고서

> 자동 생성: 2026-07-29 09:28:12
> 스크립트: `scripts/load-test.js` (Node.js 기반 k6-style 부하 테스트 러너)

## 종합 결과: ALL PASS

| 시나리오 | 결과 | 핵심 지표 |
|---------|------|----------|
| A. 일반 API 정상 부하 | PASS | 100/100 성공, TPS 571.27 |
| B. Rate Limit 방어 | PASS | 429 응답 35회, 헤더 검증 35회 |
| C. 캐시 성능 | PASS | 평균 1.81ms (임계값 <= 5ms) |

---

## 1. 테스트 환경

| 항목 | 값 |
|------|-----|
| 대상 서버 | `http://127.0.0.1` (로컬 Express 테스트 인스턴스) |
| 외부 API | Mock Fetch (네트워크 I/O 제거) |
| Node.js | v24.14.0 |
| 실행 일시 | 2026-07-29 09:28:12 |
| OS | win32 x64 |

---

## 2. 시나리오 A: 일반 API 정상 부하

| 지표 | 값 |
|------|-----|
| 대상 엔드포인트 | `/api/scenarios` |
| 총 요청 수 | 100회 |
| 동시 요청 (배치) | 10개 |
| 성공 (HTTP 200) | 100회 |
| 실패 | 0회 |
| 평균 응답 시간 | 16.08ms |
| 최대 응답 시간 | 43.45ms |
| P95 응답 시간 | 40.96ms |
| TPS | 571.27 req/s |
| 총 소요 시간 | 175ms |
| 결과 | PASS |

> 100회/분 임계값 이내에서 모든 요청이 HTTP 200으로 정상 수용됨을 확인합니다.

---

## 3. 시나리오 B: OpenAPI Rate Limit 초과 방어

| 지표 | 값 |
|------|-----|
| 대상 엔드포인트 | `/api/tour/area-code` |
| Rate Limit | 30회/분 |
| 총 요청 수 | 35회 |
| 정상 응답 (HTTP 200) | 0회 |
| 차단 응답 (HTTP 429) | 35회 |
| X-RateLimit-Limit 헤더 검증 | 35회 |
| 31번째 이후 전부 429 | YES |
| 결과 | PASS |

> OpenAPI 프록시 경로에 적용된 Rate Limiter(30회/분)가 정상 동작하여,
> 제한 초과 시 HTTP 429 + `X-RateLimit-Limit` 헤더를 반환합니다.

---

## 4. 시나리오 C: 인메모리 캐시 성능

| 지표 | 값 |
|------|-----|
| 대상 엔드포인트 | `/api/tour/area-code` |
| Cold Start (첫 요청) | 5.16ms |
| Cache Hit 측정 횟수 | 19회 |
| Cache Hit 평균 응답 | 1.81ms |
| Cache Hit 최대 응답 | 4.24ms |
| Cache Hit P95 응답 | 4.24ms |
| 임계값 | <= 5ms |
| 결과 | PASS |

> 인메모리 캐시를 통해 동일 요청의 반복 호출 시 네트워크 I/O 없이
> 극도로 빠른 응답(평균 1.81ms)을 달성합니다.

---

## 5. 시스템 안정성 평가

| 평가 항목 | 결과 |
|-----------|------|
| 부하 수용 능력 | 양호 — 100회 요청 안정 처리 |
| Rate Limiter 방어 | 정상 — 초과 요청 100% 차단 |
| 캐시 응답 속도 | 우수 — 평균 1.81ms |
| TPS (초당 처리량) | 571.27 req/s |
| 종합 판정 | ALL PASS |

---

## 6. 운영 검증 게이트 연결

| 게이트 | 결과 | 증빙 |
|--------|------|------|
| Scenario API readiness | PASS | 100/100 requests succeeded on /api/scenarios |
| OpenAPI quota protection | PASS | 35 HTTP 429 responses with rate-limit headers |
| TourAPI cache fallback readiness | PASS | cache-hit average 1.81ms, threshold <= 5ms |

> `npm run deploy:check`는 공개 URL, 정적 번들, TourAPI proxy, 시나리오 상세/공유 복원 상태를 확인하고,
> `npm run test:load`는 API 수용량, Rate Limiter, 캐시 응답성을 로컬 격리 환경에서 재현합니다.
