/**
 * 파일 : src/components/PlanForm.tsx
 * 내용 : 지자체 축제 기획안(지역, 기간, 예산, 수용 인원, 행사장 주소) 입력 및 실시간 조건 변경 폼 컴포넌트
 * 수정 : 2026-07-24. TourAPI 지역 선택 이벤트 연동 및 수용 규모 실시간 반영 폼 구현
 */

// 축제 기획안 도메인 모델 및 TourAPI 지역코드 타입 불러오기
import type { FestivalPlan } from "../domain/types";
import type { TourApiAreaCode } from "../services/tourApiAdapter";

// PlanForm 입력 프로퍼티(Props) 타입 명세
interface PlanFormProps {
  plan: FestivalPlan; // 현재 입력된 축제 기획안 상태
  onPlanChange: (plan: FestivalPlan) => void; // 기획안 수정 이벤트를 부모 컴포넌트에 전파하는 핸들러
  areaCodes: TourApiAreaCode[]; // TourAPI 행정구역 지역코드 목록
  isAreaLoading: boolean; // 지역 목록 로딩 여부
  isCandidateLoading: boolean; // 후보 축제 로딩 여부
  candidateCount: number; // 조회된 후보 축제 개수
  selectedCandidateTitle?: string; // 현재 선택된 TourAPI 축제명
  onOpenCandidates: () => void; // 후보 축제 선택 드로어 오픈 함수
}

// 축제 기획안 조건 입력 및 수정 메인 UI 컴포넌트
export function PlanForm({
  plan,
  onPlanChange,
  areaCodes,
  isAreaLoading,
  isCandidateLoading,
  candidateCount,
  selectedCandidateTitle,
  onOpenCandidates,
}: PlanFormProps) {
  const candidateStatus = isCandidateLoading
    ? "TourAPI 후보 조회 중"
    : candidateCount > 0
      ? `TourAPI 후보 ${candidateCount}건`
      : "조회된 후보 없음";

  return (
    <section className="panel">
      <div className="panel-heading">
        <h2>축제 기획안 입력</h2>
        <span>지역 우선 조회</span>
      </div>

      <div className="tourapi-example-note">
        <strong>TourAPI 지역 기반 후보 조회</strong>
        <span>
          지역과 기간을 먼저 선택한 뒤 실제 TourAPI 축제 후보를 확인합니다.
        </span>
      </div>

      <div className="form-grid">
        <label>
          개최 지역
          {areaCodes.length > 0 ? (
            <select
              value={plan.region}
              onChange={(event) =>
                onPlanChange({ ...plan, region: event.target.value })
              }
            >
              {areaCodes.map((area) => (
                <option key={area.code} value={area.name}>
                  {area.name}
                </option>
              ))}
            </select>
          ) : (
            <input
              value={plan.region}
              onChange={(event) =>
                onPlanChange({ ...plan, region: event.target.value })
              }
            />
          )}
        </label>

        <label>
          시작일
          <input
            type="date"
            value={plan.startDate}
            onChange={(event) =>
              onPlanChange({ ...plan, startDate: event.target.value })
            }
          />
        </label>

        <label>
          종료일
          <input
            type="date"
            value={plan.endDate}
            onChange={(event) =>
              onPlanChange({ ...plan, endDate: event.target.value })
            }
          />
        </label>

        <div className="candidate-lookup-card">
          <span>{isAreaLoading ? "지역 코드 조회 중" : candidateStatus}</span>
          <strong>{selectedCandidateTitle ?? plan.name}</strong>
          <button className="secondary-button" type="button" onClick={onOpenCandidates}>
            TourAPI 후보 보기
          </button>
        </div>

        <label>
          신규/선택 축제명
          <input
            value={plan.name}
            onChange={(event) => onPlanChange({ ...plan, name: event.target.value })}
          />
        </label>

        <label>
          행사장 주소
          <input
            value={plan.venueAddress}
            onChange={(event) =>
              onPlanChange({ ...plan, venueAddress: event.target.value })
            }
          />
        </label>

        <label>
          총 예산(백만원)
          <input
            min="1"
            type="number"
            value={plan.totalBudgetMillionKrw}
            onChange={(event) =>
              onPlanChange({
                ...plan,
                totalBudgetMillionKrw: Number(event.target.value),
              })
            }
          />
        </label>

        <label>
          예상 수용 인원
          <input
            min="1"
            type="number"
            value={plan.expectedCapacity}
            onChange={(event) =>
              onPlanChange({ ...plan, expectedCapacity: Number(event.target.value) })
            }
          />
        </label>
      </div>
    </section>
  );
}
